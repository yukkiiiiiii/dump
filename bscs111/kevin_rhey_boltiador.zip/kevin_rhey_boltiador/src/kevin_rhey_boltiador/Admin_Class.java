
package kevin_rhey_boltiador;

import java.util.HashMap;

public class Admin_Class {
    public static HashMap<Integer, String[]> hm = new HashMap<>();
    
    public static String admin_first_name = "admin", admin_user_name = "admin", admin_pass = "123admin", access_Type = "admin";
    public static int admin_ID = 1000;
    
    public void AdminACC()
    {
        String[] admininfo = {admin_first_name, admin_user_name, admin_pass, access_Type};
        hm.put(admin_ID, admininfo);
    }
}
