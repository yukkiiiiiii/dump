/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package kevin_rhey_boltiador;

/**
 *
 * @author Hirigo
 */
public class Kevin_rhey_boltiador {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Log_In login = new Log_In();
        login.show();
    }
    
}
