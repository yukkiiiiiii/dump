
package francine_ignacio;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JOptionPane;


public class LoginF extends javax.swing.JFrame {
public static MainData hash = new MainData();
public static RegisterF ReF = new RegisterF();
public static String LogInUsername, LogInPassword, hashuname, hashupass, hashuaccesstype;

    
    public LoginF() {
        initComponents();
        create_acc();
        hash.AdminAcc();
    }
    
    
    public void create_acc()
    {
        create_acc.addMouseListener(new MouseAdapter()
        {
            public void mouseClicked(MouseEvent e)
            {
                if(ReF == null || !ReF.isVisible())
                {
                    ReF = new RegisterF();
                }
                ReF.setVisible(true);
               Dispose();
            }          
        });
    }
    
    public void Dispose()
    {
        this.dispose();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        login_button = new javax.swing.JButton();
        login_password = new javax.swing.JTextField();
        username_login = new javax.swing.JTextField();
        create_acc = new javax.swing.JLabel();

        jLabel1.setText("jLabel1");

        jLabel2.setText("jLabel2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel3.setFont(new java.awt.Font("Segoe UI Semibold", 0, 48)); // NOI18N
        jLabel3.setText("LOGIN");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        jLabel4.setText("Password");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        jLabel5.setText("Username");

        login_button.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        login_button.setText("LOGIN");
        login_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                login_buttonActionPerformed(evt);
            }
        });

        create_acc.setText("Create an account");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(184, 184, 184)
                        .addComponent(jLabel3))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addGap(18, 18, 18)
                                .addComponent(username_login, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(login_password, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(219, 219, 219)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(login_button)
                            .addComponent(create_acc))))
                .addContainerGap(25, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(username_login, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(43, 43, 43)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(login_password, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 89, Short.MAX_VALUE)
                .addComponent(login_button)
                .addGap(18, 18, 18)
                .addComponent(create_acc)
                .addGap(25, 25, 25))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void login_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_login_buttonActionPerformed
       LogInUsername = username_login.getText();
       LogInPassword = login_password.getText();
       boolean verifyAcc = false;
       String verifyUserType = "";
       
       for(int AccID : hash.hashmp.keySet())
       {
         String[] accinfos = hash.hashmp.get(AccID);
         if(accinfos != null && accinfos.length >=4)
         {
             hashuname = accinfos[1];
             hashupass = accinfos[2];
             hashuaccesstype = accinfos[3];
             if(hashuname.equals(LogInUsername) && hashupass.equals(LogInPassword))
             {
                 verifyAcc = true;
                 verifyUserType = hashuaccesstype;
                 break;
             }
         }
                 
       }
       
       if(verifyAcc)
       {
           if("admin".equalsIgnoreCase(hashuaccesstype))
           {
               AdminTbl Atbl = new AdminTbl();
               Atbl.show();
               this.dispose();
           } else if ("user".equalsIgnoreCase(hashuaccesstype))
           {
              LibrarySystem lb = new LibrarySystem();
               lb.show();
               this.dispose();
           }else 
           {
               JOptionPane.showMessageDialog(this, "Please check your username and password properly");
           }
       }else 
       {
            JOptionPane.showMessageDialog(this, "invalid");
       }
               
    }//GEN-LAST:event_login_buttonActionPerformed

    
    public static void main(String args[]) {
      
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LoginF().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel create_acc;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JButton login_button;
    private javax.swing.JTextField login_password;
    private javax.swing.JTextField username_login;
    // End of variables declaration//GEN-END:variables
}
