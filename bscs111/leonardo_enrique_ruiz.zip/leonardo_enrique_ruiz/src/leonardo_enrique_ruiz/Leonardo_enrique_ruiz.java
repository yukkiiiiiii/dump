
package leonardo_enrique_ruiz;


public class Leonardo_enrique_ruiz {

   
    public static void main(String[] args) {
     LoginF logf = new LoginF();
     logf.show();
    }
    
}
