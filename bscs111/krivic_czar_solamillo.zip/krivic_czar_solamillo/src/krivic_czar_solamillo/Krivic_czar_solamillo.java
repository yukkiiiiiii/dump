
package krivic_czar_solamillo;


public class Krivic_czar_solamillo {

    
    public static void main(String[] args) {
       LOGIN login = new LOGIN();       
       login.show();
    }
    
}
