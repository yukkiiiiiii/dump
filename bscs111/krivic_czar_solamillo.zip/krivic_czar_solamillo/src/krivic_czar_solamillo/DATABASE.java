
package krivic_czar_solamillo;

import java.util.HashMap;


public class DATABASE {
    public static HashMap<Integer, String[]> hshmp = new HashMap<>();
    public static String adminfname = "admin", adminuname = "admin", adminupass = "12345", accessType = "admin";
    public static int adminID = 1000;
    
    
    void ADMINACCC()
    {
        String[] admin_Creds = {adminfname, adminuname, adminupass, accessType};
        hshmp.put(adminID, admin_Creds);
    }
}
