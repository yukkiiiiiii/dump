
package orderingsystem;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JOptionPane;


public class LoginForm extends javax.swing.JFrame {
public static String Loguname, Logupass, hashuname, hashupass, hashaccessType;
public static DataBase dbroot = new DataBase();
public static RegisterForm register;
    
    public LoginForm() {
        initComponents();
        gotoRegister();
        dbroot.defAdminAccess();
        
    }
    
    public void Dispose()
    {
        this.dispose();
    }
    
    public void gotoRegister()
    {
        gotoRegister.addMouseListener(new MouseAdapter()
        {
            public void mouseClicked(MouseEvent e)
            {
                if(register == null || !register.isVisible())
                {
                   register = new RegisterForm();
                }
                register.setVisible(true);
                Dispose();
            }
        });
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel6 = new javax.swing.JLabel();
        loguname = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        logupass = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        loginbtn = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        gotoRegister = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel6.setText("Username");

        jLabel7.setText("Password");

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Log In");

        loginbtn.setText("Log In");
        loginbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginbtnActionPerformed(evt);
            }
        });

        jLabel2.setText("Don't have an account yet?");

        gotoRegister.setForeground(new java.awt.Color(51, 153, 255));
        gotoRegister.setText("Register");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(126, 126, 126)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(loguname, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7)
                            .addComponent(logupass, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(22, 22, 22)
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(gotoRegister))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(201, 201, 201)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(207, 207, 207)
                        .addComponent(loginbtn)))
                .addContainerGap(139, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(loguname, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(logupass, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(loginbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(gotoRegister))
                .addContainerGap(65, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void loginbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginbtnActionPerformed
        Loguname = loguname.getText().trim();
        Logupass = logupass.getText().trim();
        String  USERTYPECHECKER = "";
        boolean accchecker = false;
        
        for(int accID : dbroot.db.keySet())
        {
            String[] accinfos = dbroot.db.get(accID);
            if(accinfos != null && accinfos.length >= 4)
            {
                hashuname = accinfos[1];
                hashupass = accinfos[2];
                hashaccessType = accinfos[3];
                if(hashuname.equals(Loguname) && hashupass.equals(Logupass))
                {
                    accchecker = true;
                    USERTYPECHECKER = hashaccessType;
                    break;
                }
            }
        }
        if(accchecker)
        {
            if("admin".equalsIgnoreCase(hashaccessType))
            {
                JOptionPane.showMessageDialog(this, "admin Frame");
            }else if("user".equalsIgnoreCase(hashaccessType))
            {
                JOptionPane.showMessageDialog(this, "user Frame");
            } else 
            {
            JOptionPane.showMessageDialog(this, "Wrong username or password. Please try again");
            }
        } else 
        {
                JOptionPane.showMessageDialog(this, "Invalid Account");
        }
    }//GEN-LAST:event_loginbtnActionPerformed

   
    public static void main(String args[]) {
      
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LoginForm().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel gotoRegister;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JButton loginbtn;
    private javax.swing.JTextField loguname;
    private javax.swing.JTextField logupass;
    // End of variables declaration//GEN-END:variables
}
