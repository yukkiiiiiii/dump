
package orderingsystem;


public class OrderingSystem {

   
    public static void main(String[] args) {
       LoginForm lf = new LoginForm();
       lf.show();
    }
    
}
