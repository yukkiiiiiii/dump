
package sean_martin_marcos;

import java.util.HashMap;


public class MainData {
    public static HashMap<Integer, String[]> hashmp = new HashMap<>();
    public static String adminfname = "root", adminuname = "root", adminupass = "toor", accessType = "admin";
    public static int adminUID = 1000;
    
    public void AdminAcc()
    {
        String[] AdminAccCreds = {adminfname, adminuname, adminupass, accessType};
        hashmp.put(adminUID, AdminAccCreds);
    }
    
}
