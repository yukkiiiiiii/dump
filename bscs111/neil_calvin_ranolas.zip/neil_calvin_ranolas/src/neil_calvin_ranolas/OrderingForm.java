
package neil_calvin_ranolas;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;


public class OrderingForm extends javax.swing.JFrame {
private int pastilQuantity = 0;
private int sisigQuantity = 0;
private int chickenSkinQuantity = 0;
   
    public OrderingForm() {
        initComponents();
        
    }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        productNameThree = new javax.swing.JLabel();
        producPriceThree = new javax.swing.JLabel();
        productNameTwo = new javax.swing.JLabel();
        producPriceTwo = new javax.swing.JLabel();
        productNameOne = new javax.swing.JLabel();
        producPriceOne = new javax.swing.JLabel();
        addSisig = new javax.swing.JButton();
        removeSisig = new javax.swing.JButton();
        addChickenSkin = new javax.swing.JButton();
        addPastil = new javax.swing.JButton();
        removeChickenSkin = new javax.swing.JButton();
        removePastil = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        cartNumber = new javax.swing.JLabel();
        producPrice4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        cartList = new javax.swing.JTable();

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(102, 102, 102));

        productNameThree.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        productNameThree.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        productNameThree.setText("Chicken Skin");
        productNameThree.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        producPriceThree.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        producPriceThree.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        producPriceThree.setText("20 Php");

        productNameTwo.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        productNameTwo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        productNameTwo.setText("Sisig");
        productNameTwo.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        producPriceTwo.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        producPriceTwo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        producPriceTwo.setText("45 Php");

        productNameOne.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        productNameOne.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        productNameOne.setText("Pastil");
        productNameOne.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        productNameOne.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        producPriceOne.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        producPriceOne.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        producPriceOne.setText("20 Php");

        addSisig.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        addSisig.setForeground(new java.awt.Color(0, 255, 0));
        addSisig.setText("+");
        addSisig.setBorder(null);
        addSisig.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addSisigActionPerformed(evt);
            }
        });

        removeSisig.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        removeSisig.setForeground(new java.awt.Color(255, 0, 0));
        removeSisig.setText("-");
        removeSisig.setBorder(null);
        removeSisig.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removeSisigActionPerformed(evt);
            }
        });

        addChickenSkin.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        addChickenSkin.setForeground(new java.awt.Color(0, 255, 0));
        addChickenSkin.setText("+");
        addChickenSkin.setBorder(null);
        addChickenSkin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addChickenSkinActionPerformed(evt);
            }
        });

        addPastil.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        addPastil.setForeground(new java.awt.Color(0, 255, 0));
        addPastil.setText("+");
        addPastil.setBorder(null);
        addPastil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addPastilActionPerformed(evt);
            }
        });

        removeChickenSkin.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        removeChickenSkin.setForeground(new java.awt.Color(255, 0, 0));
        removeChickenSkin.setText("-");
        removeChickenSkin.setBorder(null);
        removeChickenSkin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removeChickenSkinActionPerformed(evt);
            }
        });

        removePastil.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        removePastil.setForeground(new java.awt.Color(255, 0, 0));
        removePastil.setText("-");
        removePastil.setBorder(null);
        removePastil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removePastilActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(productNameTwo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(productNameOne, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(productNameThree, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(51, 51, 51)
                        .addComponent(producPriceThree, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addComponent(producPriceTwo, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(46, 46, 46)
                        .addComponent(producPriceOne, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(removeChickenSkin, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(addChickenSkin, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(addSisig, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(removeSisig, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(addPastil, javax.swing.GroupLayout.DEFAULT_SIZE, 37, Short.MAX_VALUE)
                    .addComponent(removePastil, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 70, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(70, 70, 70)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(productNameOne, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(addPastil, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(producPriceOne)
                    .addComponent(removePastil, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(productNameTwo, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(addSisig, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(producPriceTwo)
                    .addComponent(removeSisig, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(productNameThree, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(producPriceThree))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(addChickenSkin, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(removeChickenSkin, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        cartNumber.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        cartNumber.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cartNumber.setText("0");

        producPrice4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        producPrice4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        producPrice4.setText("Cart : ");

        cartList.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "food", "price"
            }
        ));
        jScrollPane1.setViewportView(cartList);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(77, 77, 77)
                .addComponent(cartNumber)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jScrollPane1)
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel4Layout.createSequentialGroup()
                    .addGap(25, 25, 25)
                    .addComponent(producPrice4)
                    .addContainerGap(318, Short.MAX_VALUE)))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(cartNumber)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 433, Short.MAX_VALUE))
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel4Layout.createSequentialGroup()
                    .addGap(29, 29, 29)
                    .addComponent(producPrice4)
                    .addContainerGap(651, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void addPastilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addPastilActionPerformed
        pastilQuantity++;
        updateCart();
    }//GEN-LAST:event_addPastilActionPerformed

    private void removePastilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removePastilActionPerformed
        if (pastilQuantity > 0) {
        pastilQuantity--;
        updateCart();
    }
    }//GEN-LAST:event_removePastilActionPerformed

    private void addSisigActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addSisigActionPerformed
        sisigQuantity++;
        updateCart();
    }//GEN-LAST:event_addSisigActionPerformed

    private void removeSisigActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removeSisigActionPerformed
        if (sisigQuantity > 0) {
        sisigQuantity--;
        updateCart();
    }
    }//GEN-LAST:event_removeSisigActionPerformed

    private void addChickenSkinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addChickenSkinActionPerformed
        chickenSkinQuantity++;
    updateCart();
    }//GEN-LAST:event_addChickenSkinActionPerformed

    private void removeChickenSkinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removeChickenSkinActionPerformed
         if (chickenSkinQuantity > 0) {
        chickenSkinQuantity--;
        updateCart();
    }
    }//GEN-LAST:event_removeChickenSkinActionPerformed
   
    private void updateCart() {
    DefaultTableModel model = (DefaultTableModel) cartList.getModel();
    model.setRowCount(0);  // Clear existing rows

    // Add items to the table
    if (pastilQuantity > 0) {
        model.addRow(new Object[]{"Pastil", "20 Php", pastilQuantity});
    }
    if (sisigQuantity > 0) {
        model.addRow(new Object[]{"Sisig", "45 Php", sisigQuantity});
    }
    if (chickenSkinQuantity > 0) {
        model.addRow(new Object[]{"Chicken Skin", "20 Php", chickenSkinQuantity});
    }

    // Update cart number (total count of items)
    int totalItems = pastilQuantity + sisigQuantity + chickenSkinQuantity;
    cartNumber.setText(String.valueOf(totalItems));
}
    
     
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new OrderingForm().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addChickenSkin;
    private javax.swing.JButton addPastil;
    private javax.swing.JButton addSisig;
    private javax.swing.JTable cartList;
    private javax.swing.JLabel cartNumber;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel producPrice4;
    private javax.swing.JLabel producPriceOne;
    private javax.swing.JLabel producPriceThree;
    private javax.swing.JLabel producPriceTwo;
    private javax.swing.JLabel productNameOne;
    private javax.swing.JLabel productNameThree;
    private javax.swing.JLabel productNameTwo;
    private javax.swing.JButton removeChickenSkin;
    private javax.swing.JButton removePastil;
    private javax.swing.JButton removeSisig;
    // End of variables declaration//GEN-END:variables
}
