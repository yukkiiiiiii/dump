
package neil_calvin_ranolas;

import java.util.HashMap;


public class DataBase {
    public static HashMap<Integer, String[]> db = new HashMap<>();
    
    public static String adminfname = "root", adminuname = "root", adminupass = "toor", accessType = "admin";
    public static int adminUID = 1000;
    
    static void defAdminAccess()
    {
        String[] AdminAccessCred = {adminfname, adminuname, adminupass, accessType};
        db.put(adminUID, AdminAccessCred);
    }
    
}
