
package francine_ignacio;


public class Francine_ignacio {

    
    public static void main(String[] args) {
       LOGIN lf = new LOGIN();
       lf.show();
       
    }
    
}
