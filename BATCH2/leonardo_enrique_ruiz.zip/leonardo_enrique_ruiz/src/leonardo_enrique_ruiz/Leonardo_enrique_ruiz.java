
package leonardo_enrique_ruiz;


public class Leonardo_enrique_ruiz {

   
    public static void main(String[] args) {
     LOGIN logf = new LOGIN();
     logf.show();
    }
    
}
