
package ashley_yumul;

import java.util.HashMap;


public class DATABASE {
    public static HashMap<Integer, String[]> hshmp = new HashMap<>();
    public static HashMap<Integer, String[]> dbproducts = new HashMap<>();
    public static String adminfname = "admin", adminuname = "admin", adminupass = "12345", accessType = "admin";
    public static String defFirstName = "rawr", defUserName = "ash", defUserPass = "1234", Access_Type = "user";
    public static int adminID = 1000;
    
    
    void ADMINACCC()
    {
        String[] admin_Creds = {adminfname, adminuname, adminupass, accessType};
        hshmp.put(adminID, admin_Creds);
    }
    
    void Default_User_Account()
    {
        String[] User_Default_Account = {defFirstName, defUserName, defUserPass, Access_Type};
        hshmp.put(adminID, User_Default_Account);
    }
    
    public void updateProduct(int uid, String[] updatedDetails) {
    if (dbproducts.containsKey(uid)) {
        dbproducts.put(uid, updatedDetails);
    } else {
        System.out.println("Product UID not found!");
    }
}
}
