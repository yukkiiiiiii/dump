
package joy_rivera;


public class Joy_rivera {

    
    public static void main(String[] args) {
       LOGIN login = new LOGIN();
       login.setVisible(true);
    }
    
}
