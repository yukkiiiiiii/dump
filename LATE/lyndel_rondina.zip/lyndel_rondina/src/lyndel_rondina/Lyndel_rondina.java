/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lyndel_rondina;

/**
 *
 * @author Hirigo
 */
public class Lyndel_rondina {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       LOGIN log = new LOGIN();
       log.show();
    }
    
}
