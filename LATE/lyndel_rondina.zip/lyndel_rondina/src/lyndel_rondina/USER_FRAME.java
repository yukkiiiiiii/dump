
package lyndel_rondina;

import javax.swing.table.DefaultTableModel;


public class USER_FRAME extends javax.swing.JFrame {
public static DATABASE dbprod = new DATABASE();
    
    public USER_FRAME() {
        initComponents();
        order_list();
        food_list();
    }
    
   public void order_list()
   {
       DefaultTableModel orderModel = new DefaultTableModel();
       orderModel.setColumnIdentifiers(new String[]{"Food UID", "Food Name", "Food Price", "QTY"});
       ordertable.setModel(orderModel);
   }
    
    public void food_list()
    {
        DefaultTableModel dtms = new DefaultTableModel();
        dtms.setColumnIdentifiers(new String[]{"Food UID", "Food Name", "Food Price", "QTY"});
        
        for(Integer gettableset : dbprod.dbproducts.keySet())
        {
            String[] tablegetsdata = dbprod.dbproducts.get(gettableset);
            dtms.addRow(new Object[]{gettableset, tablegetsdata[0], tablegetsdata[1], tablegetsdata[2]});
        }
        foodlist.setModel(dtms);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        foodlist = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        removeorder = new javax.swing.JButton();
        addorder = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        ordertable = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        numoforder = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        foodlist.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(foodlist);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel2.setText("Food List");

        removeorder.setText("Delete Order");
        removeorder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removeorderActionPerformed(evt);
            }
        });

        addorder.setText("Add Order");
        addorder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addorderActionPerformed(evt);
            }
        });

        ordertable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(ordertable);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel3.setText("Order List");

        jLabel1.setText("QTY of order");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 832, Short.MAX_VALUE)
                        .addComponent(jLabel2)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(addorder, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(removeorder, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(numoforder, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addComponent(jScrollPane1))
                    .addComponent(jLabel3))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 365, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(addorder, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(removeorder, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(numoforder, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void addorderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addorderActionPerformed
        int selectedRow = foodlist.getSelectedRow();
        if (selectedRow == -1) {
            javax.swing.JOptionPane.showMessageDialog(this, "Please select a food item to add.");
            return;
        }

        String orderQtyText = numoforder.getText().trim();
        if (orderQtyText.isEmpty() || !orderQtyText.matches("\\d+")) {
            javax.swing.JOptionPane.showMessageDialog(this, "Please enter a valid quantity.");
            return;
        }

        int orderQty = Integer.parseInt(orderQtyText);

        if (orderQty <= 0) {
            javax.swing.JOptionPane.showMessageDialog(this, "Quantity must be greater than zero.");
            return;
        }

        DefaultTableModel foodModel = (DefaultTableModel) foodlist.getModel();
        DefaultTableModel orderModel = (DefaultTableModel) ordertable.getModel();

        Object foodUID = foodModel.getValueAt(selectedRow, 0);
        Object foodName = foodModel.getValueAt(selectedRow, 1);
        Object foodPrice = foodModel.getValueAt(selectedRow, 2);

       
        orderModel.addRow(new Object[]{foodUID, foodName, foodPrice, orderQty});
        
         numoforder.setText("");
        
        javax.swing.JOptionPane.showMessageDialog(this, "Food item added to the order list.");
       
    }//GEN-LAST:event_addorderActionPerformed

    private void removeorderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removeorderActionPerformed
            int selectedRow = ordertable.getSelectedRow();
        if (selectedRow == -1) {
            javax.swing.JOptionPane.showMessageDialog(this, "Please select an order to remove.");
            return;
        }

        DefaultTableModel orderModel = (DefaultTableModel) ordertable.getModel();
        orderModel.removeRow(selectedRow);

        javax.swing.JOptionPane.showMessageDialog(this, "Order removed successfully.");
    }//GEN-LAST:event_removeorderActionPerformed

    
    public static void main(String args[]) {
    
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new USER_FRAME().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addorder;
    private javax.swing.JTable foodlist;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField numoforder;
    private javax.swing.JTable ordertable;
    private javax.swing.JButton removeorder;
    // End of variables declaration//GEN-END:variables
}
