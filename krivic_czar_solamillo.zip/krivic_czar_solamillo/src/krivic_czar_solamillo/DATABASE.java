
package krivic_czar_solamillo;

import java.util.HashMap;


public class DATABASE {
    public static HashMap<Integer, String[]> hshmp = new HashMap<>();
    public static HashMap<Integer, String[]> dbproducts = new HashMap<>();  
    public static String adminfname = "admin", adminuname = "admin", adminupass = "12345", accessType = "admin";
    public static String deffirstname = "lalers", defusername ="espresso", defuserpass = "12345", accesstype = "user";
    public static int defuserID = 10000;
    public static int adminID = 1000;
    
    
    void DEFUSERACC()
    {
        String[] defuser_creds = {deffirstname, defusername, defuserpass, accesstype};
        hshmp.put(defuserID, defuser_creds);
    }
    
    void ADMINACCC()
    {
        String[] admin_Creds = {adminfname, adminuname, adminupass, accessType};
        hshmp.put(adminID, admin_Creds);
    }
    
    public void updateProduct(int uid, String[] updatedDetails) {
    if (dbproducts.containsKey(uid)) {
        dbproducts.put(uid, updatedDetails);
    } else {
        System.out.println("Product UID not found!");
    }
}
}
